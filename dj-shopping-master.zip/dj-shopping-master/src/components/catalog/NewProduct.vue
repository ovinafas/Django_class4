<template>
  <div class="recommended_items">
    {{ title }}
  </div>
</template>

<script>
// import RetailSale from "./RetailSale";
export default {
  name: `NewProduct`,
  data() {
    return {
      title: "New Product",
    };
  },
  components: {
    // HeaderTop,
  },
};
</script>
