<template>
    <div class="header-middle">
        middle
    </div>
</template>

<script>
export default {
    name: `HeaderMiddle`,
};
</script>